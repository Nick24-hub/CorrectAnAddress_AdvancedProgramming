package com.example.ProiectJavav2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProiectJavav2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProiectJavav2Application.class, args);
	}

}
